
import React from "react";
import AssistCampusMate from "@/components/AssistCampusMate";

const AssistChat = () => {
  return <AssistCampusMate />;
};

export default AssistChat;
