
import React from "react";
import CampusMate from "@/components/CampusMate";

const FriendlyChat = () => {
  return <CampusMate />;
};

export default FriendlyChat;
